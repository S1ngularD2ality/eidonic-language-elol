# glyph_675 – HAZARD_MARKER_DEPLOY
# Deploy visual marker to warn others of hazard

def glyph_675(hazard_location):
    return f"Marker placed at {hazard_location}"
