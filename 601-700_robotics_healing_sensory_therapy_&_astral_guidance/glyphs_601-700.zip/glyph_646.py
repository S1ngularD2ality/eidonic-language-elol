# glyph_646 – EMERGENCY_RESOURCE_DROP
# Drop essential supplies in a safe location

def glyph_646(location, supply_type):
    return f"Supplies ({supply_type}) dropped at {location}"
