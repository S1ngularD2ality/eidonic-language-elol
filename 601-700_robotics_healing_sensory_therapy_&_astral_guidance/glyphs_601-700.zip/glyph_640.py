# glyph_640 – SENSITIVE_MATERIAL_ALERT
# Alert operator about sensitive material handling

def glyph_640(material_type):
    return f"Alert: Handle {material_type} with care."
