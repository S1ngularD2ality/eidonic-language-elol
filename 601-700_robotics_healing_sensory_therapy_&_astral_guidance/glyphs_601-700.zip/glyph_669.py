# glyph_669 – LOW_VIBRATION_MODE
# Reduce vibration for fragile environments

def glyph_669(current_vibration):
    return current_vibration * 0.5
