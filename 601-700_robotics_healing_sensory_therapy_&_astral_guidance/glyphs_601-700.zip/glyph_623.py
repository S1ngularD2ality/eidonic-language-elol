# glyph_623 – ASSISTIVE_PUSH
# Provide minimal force to assist without overpowering human effort

def glyph_623(human_force, assist_ratio=0.5):
    return human_force * assist_ratio
