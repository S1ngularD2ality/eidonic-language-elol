# glyph_639 – HUMAN_ASSIST_BEACON
# Send visible beacon to indicate readiness to assist

def glyph_639(is_ready):
    return 'BEACON_ON' if is_ready else 'BEACON_OFF'
