# glyph_654 – ACCESSIBILITY_MODE
# Adjust height and reach for accessibility

def glyph_654(user_height):
    return max(0.5, min(2.0, user_height))
