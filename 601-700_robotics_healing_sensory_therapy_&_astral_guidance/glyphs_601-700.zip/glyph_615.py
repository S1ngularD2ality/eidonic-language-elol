# glyph_615 – NOISE_REDUCTION_MOVEMENT
# Reduce motor noise for peaceful operation

def glyph_615(motor_speed):
    return motor_speed * 0.8
