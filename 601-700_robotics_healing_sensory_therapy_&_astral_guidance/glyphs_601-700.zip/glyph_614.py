# glyph_614 – WATER_CONSERVATION_MODE
# Optimize liquid usage for cleaning or watering tasks

def glyph_614(amount, conservation_factor=0.75):
    return amount * conservation_factor
