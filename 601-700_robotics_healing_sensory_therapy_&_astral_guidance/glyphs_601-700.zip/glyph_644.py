# glyph_644 – RESCUE_MODE
# Switch to high-priority life-assist actions in emergencies

def glyph_644(is_emergency):
    return 'rescue_protocol' if is_emergency else 'normal'
