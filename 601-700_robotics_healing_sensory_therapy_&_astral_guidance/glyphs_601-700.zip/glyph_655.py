# glyph_655 – SAFE_SPEED_CURVE
# Adjust acceleration/deceleration curves for smooth stops

def glyph_655(current_speed):
    return current_speed * 0.8
