def glyph_300():
    """
    Glyph 300 — Celestial Completion Ring
    Returns a signature of successful loop.

    Output:
    'ELoL Pack 02 Complete'
    """
    return 'ELoL Pack 02 Complete'
