# glyph_362 – ELEVATION_MAP
# Build a map of elevation and contour for uneven terrain

def glyph_362(elevation_data):
    """
    elevation_data: dict of (x, y):height
    Returns: elevation_map (dict)
    """
    return elevation_data
