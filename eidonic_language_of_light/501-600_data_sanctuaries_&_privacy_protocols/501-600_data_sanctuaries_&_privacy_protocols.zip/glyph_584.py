# glyph_584.py — Decrypt Video Stream
# -----------------------------------------------------------------------------
# ID:            584
# Pack:          Pack 006 (501–600)
# Name:          Decrypt Video Stream
# Class:         media_stream
# Stability:     Stable
# Version:       1.1.0
# Since:         2025-09-29
# Deterministic: True   # chunked unseal
# Thread-Safe:   True
# Provenance:    index_md='glyph_index_pack_006.md', manifest_json='glyph_manifest_pack_006.json'
# License:       EIDONIC COMMUNITY LICENSE — NON-COMMERCIAL v1.1 (ECL-NC-1.1)
# -----------------------------------------------------------------------------
from typing import List

def glyph_584(ct_frames: List[bytes], tags: List[bytes], *, key: bytes, nonce_base: bytes) -> List[bytes]:
    """
    Decrypt Video Stream — unseal a sequence of sealed frames.

    Returns
    -------
    List[bytes]

    Examples
    --------
    >>> env = glyph_583([b'A',b'B'], key=b'k', nonce=b'n')
    >>> glyph_584(env['ct_frames'], env['tags'], key=b'k', nonce_base=env['nonce_base'])
    [b'A', b'B']
    """
    out: List[bytes] = []
    for i, ct in enumerate(ct_frames):
        sealed = {"nonce": nonce_base + i.to_bytes(4, "big"), "ct": ct, "tag": tags[i]}
        out.append(glyph_502(sealed, key=key))  # type: ignore
    return out
