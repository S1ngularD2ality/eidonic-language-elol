# glyph_772 – REDUNDANCY_VERIFICATION
# Verify backup data matches the live system.

def glyph_772(live_data, backup_data):
    return live_data == backup_data
