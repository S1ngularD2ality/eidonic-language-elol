def glyph_186(input_data):
    """
    Returns the input unchanged.

    Example:
    Input: 'anything'
    Output: 'anything'
    """
    return input_data
