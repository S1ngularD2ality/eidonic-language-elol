# glyph_526 – TWO_FACTOR_CODE
# Generate a one-time two-factor authentication code

import random

def glyph_526():
    return str(random.randint(100000, 999999))
