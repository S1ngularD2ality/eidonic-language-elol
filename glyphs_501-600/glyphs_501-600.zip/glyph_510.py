# glyph_510 – TOKEN_VALIDATE
# Validate if token exists in authorized list

def glyph_510(token, authorized_tokens):
    return token in authorized_tokens
