# glyph_535 – FIREWALL_RULE
# Add a rule to block or allow traffic

def glyph_535(rule_list, rule):
    rule_list.append(rule)
    return rule_list
